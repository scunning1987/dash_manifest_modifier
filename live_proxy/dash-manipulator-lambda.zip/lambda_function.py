'''
Copyright (c) 2021 Scott Cunningham

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Summary: This script is designed to parse and modify an MPEG DASH manifest.

Original Author: Scott Cunningham
'''

import json
import boto3
import datetime
import math
import os
import requests
import xmltodict

import logging

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)
MANIFESTMODIFY="True"

def lambda_handler(event, context):

    def error_response(message):
        LOGGER.error(message)
        error_message = {"error":{
            "message":message,
            "mpd_url": mpd_url
        }}
        return {
            'statusCode': 500,
            "headers": {
                "Content-Type": "application/xml",
                "Access-Control-Allow-Origin":"*"
            },
            'body': xmltodict.unparse(error_message,short_empty_elements=True, pretty=True)
            }

    LOGGER.info("event : %s" % (str(event)))

    origin = ""
    try:
        if "origin" in event['queryStringParameters']:
            encoded_origin = event['queryStringParameters']['origin']
            origin = encoded_origin.replace("%2F","/")
            origin = origin.replace("%3A",":")
            LOGGER.info("Origin query string was sent with request, overriding static origin and using %s" % (origin))
        else:
            origin = os.environ['ORIGIN']
    except:
        origin = os.environ['ORIGIN']
    
    mpd_url = origin + event['path']

    mpd_path = mpd_url.rsplit('/', 1)[0]
    mpd_xml = requests.get(url = mpd_url)
    if mpd_xml.status_code != 200:
        return error_response("Unable to get manifest from origin, got code %s " % (str(mpd_xml.status_code)))

    mpd_xml_live = mpd_xml.text.replace("\n"," ")
    mpd_json = xmltodict.parse(mpd_xml.text)

    mpddoc = xmltodict.parse(mpd_xml_live)
    manifest_modify_exceptions = []
    
    if MANIFESTMODIFY == "True":
        
        ### All of the MPD modify/delete actions below are inside TRY blocks
        ### Add or remove more modify/delete/add actions inside individual TRY block
        ### Any exceptions will be caught and displayed in a DEBUG message. 
        ### An exception does not cause the workflow to fail
        
        LOGGER.info("Manifest Modifier: Starting...")
        
        ### Modify at the MPD Level Here ### START
        # EXAMPLE : mpddoc['MPD']['@attribute'] == XX
        
        try:
            mpddoc['MPD']['@profiles'] = "urn:mpeg:dash:profile:isoff-live:2011"
        except Exception as e:
            manifest_modify_exceptions.append("Can't change profile attribute value : %s" % (e))
        
        ### Modify at the MPD Level Here ### END
        
        if isinstance(mpddoc['MPD']['Period'], list):
            periods = len(mpddoc['MPD']['Period'])
            LOGGER.debug("Manifest Modifier: Manifest has %s Periods" % (str(periods)))
            p_layout = "m"
        else:
            periods = 1
            LOGGER.debug("Manifest Modifier: Manifest has %s Periods" % (str(periods)))
            p_layout = "s"
        ### PERIOD
        for period in range(0,periods):
            if p_layout == "s":
                p = mpddoc['MPD']['Period']
            else:
                p = mpddoc['MPD']['Period'][period]
                
            ### Modify at the Period Level Here ### START
            ## p['attribute']
            try:
                del p['@start']
            except Exception as e:
                manifest_modify_exceptions.append("Period %s : Unable to remove start attribute : %s" % (period,e))
            try:
                del p['EventStream']
            except Exception as e:
                manifest_modify_exceptions.append("Period %s : Unable to remove EventStream element : %s" % (period,e))
        
            ### Modify at the Period Level Here ### END
            
            ### ADAPTATION SET
            if isinstance(p['AdaptationSet'], list):
                adaptationsets = len(p['AdaptationSet'])
                LOGGER.debug("Manifest Modifier: Period %s has %s AdaptationSets" % (str(period),str(adaptationsets)))
                a_layout = "m"
            else:
                adaptationsets = 1
                a_layout = "s"
            for adaptationset in range(0,adaptationsets):
                LOGGER.debug("Manifest Modifier: Iterating through AS %s " % (str(adaptationset)))
                if a_layout == "s":
                    a = p['AdaptationSet']
                else:
                    a = p['AdaptationSet'][adaptationset]
                
                ### Modify at the AdaptationSet Level Here ### START
                ## a['attribute']
                try:
                    a['@segmentAlignment'] = "true"
                except Exception as e:
                    manifest_modify_exceptions.append("Period %s - AdaptationSet %s : Unable to change segmentAlignment value : %s" % (period,adaptationset,e))
        
                try: # hard-code CC accessibility elements
                    a['Role'] = {}
                    a['Role']['@schemeIdUri'] = "urn:mpeg:dash:role:2011"
                    a['Role']['@value'] = "main"
                    if a['@mimeType'] == "video/mp4":
                        a['Accessibility'] = {}
                        a['Accessibility']['@schemeIdUri'] = "urn:scte:dash:cc:cea-608:2015"
                        a['Accessibility']['@value'] = "CC1=eng"
                except Exception as e:
                    manifest_modify_exceptions.append("Period %s - AdaptationSet %s : Unable to add Closed Caption Elements : %s" % (period,adaptationset,e))

                
        
                ### Modify at the AdaptationSet Level Here ### END
                
        
                ### REPRESENTATION ###
                if isinstance(a['Representation'], list):
                    representations = len(a['Representation'])
                    LOGGER.debug("Manifest Modifier: AdaptationSet %s has %s Representations" % (str(adaptationset),str(representations)))
                    r_layout = "m"
                else:
                    representations = 1
                    LOGGER.debug("Manifest Modifier: AdaptationSet %s has %s Representations" % (str(adaptationset),str(representations)))
                    r_layout = "s"
                for representation in range(0,representations):
                    LOGGER.debug("Manifest Modifier: Iterating through Representation %s " % (str(representation)))
                    if r_layout == "s":
                        r = a['Representation']
                    else:
                        r = a['Representation'][representation]
                    
                    ### Modify at the Representation Level Here ### START
                    ## r['attribute']
                    
                    try:
                        media_template = r['SegmentTemplate']['@media']
                        init_template = r['SegmentTemplate']['@initialization']
                    except Exception as e:
                        return error_response("Manifest parse issue: Expected Representation element attributes: media and initialization")
                    
                    if "../" in media_template:
                        relative_paths = int(media_template.count("../"))
                        media_template_full = mpd_path.rsplit('/',relative_paths)[0] + "/" + media_template.replace("../","")
                        init_template_full = mpd_path.rsplit('/',relative_paths)[0] + "/" + init_template.replace("../","")
                    else:
                        relative_paths = 0
                        media_template_full = mpd_path.rsplit('/',relative_paths)[0] + "/" + media_template.replace("../","")
                        init_template_full = mpd_path.rsplit('/',relative_paths)[0] + "/" + init_template.replace("../","")
                    
                    r['SegmentTemplate']['@media'] = media_template_full
                    r['SegmentTemplate']['@initialization'] = init_template_full
                    
                    ### Modify at the Representation Level Here ### END

        LOGGER.info("Manifest Modifier: Complete...")
        LOGGER.info("Manifest Modifier: Exceptions during modify : %s " % (str(len(manifest_modify_exceptions))))
        LOGGER.debug("Manifest Modifier - Exceptions caught : %s " % (manifest_modify_exceptions))
    
        new_mpd = xmltodict.unparse(mpddoc, short_empty_elements=True, pretty=True)
    else:
        new_mpd = mpd_xml_live # no change from original MPD
        
    return {
    'statusCode': 200,
    "headers": {
        "Content-Type": "application/xml",
        "Access-Control-Allow-Origin":"*"
    },
    'body': new_mpd
    }